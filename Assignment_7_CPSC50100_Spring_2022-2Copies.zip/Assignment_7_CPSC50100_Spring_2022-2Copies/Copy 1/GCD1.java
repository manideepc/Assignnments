import java.util.*;
class GCD1
{
	
     int gcd(int num1, int num2) 
    {
      if (num2 == 0)
        return num1;
      return gcd(num2, num1 % num2);
    }

	public static void main(String[] args) throws ArithmeticException
	{   
        try{
		//int num1 = 98, num2 = 4;
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter Number 1:");

        int num1 = myObj.nextInt();  // Read user input
        System.out.println("Enter Number 2:"); 
        int num2 = myObj.nextInt(); 
        GCD1 g=new GCD1();
        int res=g.gcd(num1, num2);
        if(res==1) throw new ArithmeticException("GCD of " + num1 +" and " + num2 + " is " + g.gcd(num1, num2));
		System.out.println("GCD of " + num1 +" and " + num2 + " is " + g.gcd(num1, num2));
        }
        catch(ArithmeticException iae)
        {
            iae.printStackTrace();
        }
	}
};