class Queue extends RuntimeException
{
	private static int front, rear, capacity=10;
	private static char queue[];

	Queue() 
	{
		front = rear = 0;
        queue=new char[10];
	}

	 void Enqueue(char data)
	{

		if (capacity == rear) {
			throw new RuntimeException("Queue is Full");
			
		}

		else {
			queue[rear] = data;
			rear++;
		}
		return;
	}

	 void Dequeue()
	{

		if (front == rear) {
			throw new RuntimeException("Queue Underflow");
			
		}


		else {
			for (int i = 0; i < rear - 1; i++) {
				queue[i] = queue[i + 1];
			}

			if (rear < capacity)
				queue[rear] = 0;
			rear--;
		}
		return;
	}

	 void Display()
	{
		int i;
		if (front == rear) {
			throw new RuntimeException("Queue is Empty");
			
		}

		for (i = front; i < rear; i++) 
        {   
            
			System.out.printf(" %c ", queue[i]);
            if(i<(rear-1)) System.out.printf("-");
            
		}
		return;
	}

    public static void main(String[] args)
	{
        try{
                        Queue q = new Queue();
                        q.Enqueue('a');
                        q.Enqueue('b');
                        q.Enqueue('a');
                        q.Enqueue('a');
                        q.Enqueue('a');
                        q.Enqueue('a');
                        q.Enqueue('a');
                        q.Enqueue('b');
                        q.Display();
        }
        catch(RuntimeException iae)
        {
            iae.printStackTrace();
        }
	}

}




	
