import java.util.*;
class GCD2
{
	
    static int gcd(int n1, int n2) 
    {
        if (n1 == 0)
        return n2;
        if (n2 == 0)
        return n1;
     if (n1 == n2)
         return n1;
     if (n1 > n2)
         return gcd(n1-n2, n2);
     return gcd(n1, n2-n1);
    }

	public static void main(String[] args) throws ArithmeticException
	{   
        try{
		//int n1 = 98, n2 = 4;
        Scanner myObj = new Scanner(System.in);  // Create  Scanner object
        System.out.println("Please Enter Number 1:");
        int n1 = myObj.nextInt();  // Read user input
        System.out.println("Please Enter Number 2:"); 
        int n2 = myObj.nextInt(); 
        
        int res=gcd(n1, n2);
        if(res==1) throw new ArithmeticException("GCD of the" + n1 +" and " + n2 + " is " + gcd(n1, n2));
		System.out.println("GCD of the " + n1 +" and " + n2 + " is " + gcd(n1, n2));
        }
        catch(ArithmeticException iae)
        {
            iae.printStackTrace();
        }
	}
};