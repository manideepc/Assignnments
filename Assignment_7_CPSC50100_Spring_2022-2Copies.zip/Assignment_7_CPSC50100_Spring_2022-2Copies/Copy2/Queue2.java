class Queue extends RuntimeException
{
	private static int front_ptr, rear_ptr, size;
	private static char queue[];

	Queue() 
	{
		front_ptr = rear_ptr = 0;
        size=10;
        queue=new char[size];
	}

	static void Enqueue(char value)
	{

		if (size == rear_ptr) {
			throw new RuntimeException("Queue  Full");
			
		}

		else {
			queue[rear_ptr] = value;
			rear_ptr++;
		}

	}

	static void Dequeue()
	{

		if (front_ptr == rear_ptr) {
			throw new RuntimeException("Queue is Underflow");
			
		}
		else 
        {   
            int i=0;
			while ( i++ < (rear_ptr - 1)) 
            {
				queue[i] = queue[i + 1];
			}

			if (rear_ptr < size)
				queue[rear_ptr] = 0;
			rear_ptr--;
		}

	}

	static void Display()
	{
		int i=front_ptr;
		if (front_ptr == rear_ptr) {
			throw new RuntimeException("Queue Empty");
			
		}

        while((i++)<rear_ptr)
        {   
            
			System.out.printf(" %c ", queue[i]);
            if(i<(rear_ptr-1)) System.out.printf("->");
            
		}

	}

    public static void main(String[] args)
	{
        try{
                       
                        Queue que = new Queue();
                        que.Enqueue('a');
                        que.Enqueue('a');
                        que.Enqueue('a');
                        que.Enqueue('a');
                        que.Enqueue('a');
                        que.Enqueue('a');
                        que.Enqueue('a');
                        que.Enqueue('b');
                        que.Display();
        }
        catch(RuntimeException RE)
        {
            RE.printStackTrace();
        }
	}

}




	
